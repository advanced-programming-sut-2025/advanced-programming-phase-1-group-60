package models;

public class Tools extends Item {
    private int toolLevel;
    private String type;
    private Map <String, Object>  attributes;
    private int upgradeCost;
    private int energyCost;
}
