package models;

public class Weather {
    private String type;
    private String forecast;
}
