package models;

import java.util.List;

public class Inventory {
    private List<Item> items;
    private int capacity;
}
