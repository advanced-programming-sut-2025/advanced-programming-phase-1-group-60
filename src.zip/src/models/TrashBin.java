package models;

import java.util.List;

public class TrashBin {
    private String type;
    private List<Item> items;
}
