package models;

public class Tile {
    private int positionX;
    private int positionY;
    private String type;
    private boolean isOccupied;

}
