package models;

public class Farm {
    private List<Tile> tiles;
    private User owner;
    private List<Building> buildings;
    private int width;
    private int height;
    private int id;
    private Item randomItem;
}
