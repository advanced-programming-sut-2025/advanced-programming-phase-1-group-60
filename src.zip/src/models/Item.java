package models;

public class Item {
    private int id;
    private String name;
    private String type;
    private int quantity;
    private Map<String, Object> properties;
}
