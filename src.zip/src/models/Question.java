package models;

public class Question {
    private String question;
    private String answer;
}
