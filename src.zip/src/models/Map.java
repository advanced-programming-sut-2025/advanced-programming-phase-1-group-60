package models;

public class Map {
    private List<Farm> farms;
    private int width;
    private int height;
    private Village village;

}
